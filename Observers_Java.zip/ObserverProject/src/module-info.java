/**
 * 
 */
/**
 * 
 */
module ObserverProject {
	requires java.desktop;
}
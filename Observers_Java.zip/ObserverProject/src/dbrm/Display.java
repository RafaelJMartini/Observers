package dbrm;

public abstract class Display {

}
